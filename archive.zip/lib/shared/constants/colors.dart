import 'package:hexcolor/hexcolor.dart';
import 'package:flutter/material.dart';

HexColor orangeColor = HexColor("#FF4B26");
HexColor blackColor = HexColor("#1C1C1C");
HexColor whiteColor = HexColor("#FFFFFF");
HexColor scaffoldColorDark = HexColor("#161616");
Color scaffoldColorLight = Colors.white;
HexColor silverColor = HexColor("#5F5A5A");
HexColor textFieldColor = HexColor("#5F5A5A");
HexColor containerColor = HexColor("#262626");