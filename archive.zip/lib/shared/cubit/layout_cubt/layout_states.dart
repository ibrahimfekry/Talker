abstract class LayoutStates {}

class InitialHomeLayoutStates extends LayoutStates{}

class ChangeBottomIndex extends LayoutStates{}

//////////////////////// change app mode
class ChangeAppMode extends LayoutStates{}

