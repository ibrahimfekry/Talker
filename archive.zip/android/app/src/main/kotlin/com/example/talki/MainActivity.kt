package com.example.talki

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
